import struct
import sys


if len(sys.argv) != 3:
    sys.exit(1)

in_file    = sys.argv[1]
out_file   = sys.argv[2]

with open(in_file, 'rb') as f_in, open(out_file, 'w', encoding='utf-8') as f_out:
    while True:
        data = f_in.read(4)
        if not data:
            break
        num, = struct.unpack("<I", data)
        f_out.write(f"{num}\n")
