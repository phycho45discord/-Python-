import struct
import os

print(os.path.join(os.getcwd(), 'random_numbers.txt'))

with open('random_numbers.txt', 'r') as f:
    numbers = [int(line.strip()) for line in f if line.strip()]

print(numbers[:10])

with open('random_numbers.bin', 'wb') as f:
    for n in numbers:
        f.write(struct.pack('I', n))

print(f'转换完成，共 {len(numbers)} 个整数')